/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import java.io.FileNotFoundException;
import test.LoadingProb;

/**
 *
 * @author Lenovo
 */
public class LoadDataRecords {
    public static void main(String args[]) throws FileNotFoundException
    {
        String data="Facebook,fake,ameerkhan,Movies,Jagan,politics,person89,person10,topic92,Positive, 2017-11-05 15:23:44.888";
        DataRecord dataRecord=new DataRecord(data);
        LoadingProb loadingProb=new LoadingProb();
        showProb(dataRecord, loadingProb);
          /*    
        System.out.println(""+dataRecord.origin_of_news);
        System.out.println(""+dataRecord.fake);
        System.out.println(""+dataRecord.about_field);
        System.out.println(""+dataRecord.about_whom);
        System.out.println(""+dataRecord.by_field);
        System.out.println(""+dataRecord.by_whom);
        System.out.println(""+dataRecord.sender);
        System.out.println(""+dataRecord.receiver);
        System.out.println(""+dataRecord.topic);
        System.out.println(""+dataRecord.analysis);
        System.out.println(""+dataRecord.timestamp);
      */  
    }
    public static void showProb(DataRecord dataRecord,LoadingProb loadingProb)
    {
        System.out.print(" "+ loadingProb.origin_news.get(dataRecord.origin_of_news));
        System.out.print( " "+loadingProb.news_made.get(dataRecord.by_whom));   
        System.out.print( " "+loadingProb.about_person.get(dataRecord.sender));   
        System.out.println( " "+loadingProb.about_person.get(dataRecord.receiver));   
    
    
    }
    
}
