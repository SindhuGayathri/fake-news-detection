/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import java.io.FileNotFoundException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;
import test.LoadingProb;

 public class UpdatedBotDetection 
 {
     public static String bot_user;
     public static Timestamp bot_timTimestamp;
     public static void main(String args[]) throws FileNotFoundException
     {
       String user="person70";  
       String topic="topic11";
       String timestamp="2017-11-06 06:35:39.214";
       ArrayList<DataRecord> data_set=DatasetRead.getLoadedList("updated_data_set.txt");
       LoadingProb loadingProb=new LoadingProb();
      
       UpdatedBotDetection b=new UpdatedBotDetection();
       Timestamp ts=b.getTimestamp(timestamp);
       bot_timTimestamp=ts;
       bot_user=user;
        b.recur_backtrack(user, topic, data_set, loadingProb,ts);
         JOptionPane.showMessageDialog(null,bot_timTimestamp+""+user);
     
     }
      public static Timestamp getTimestamp(String time)
 {
        StringTokenizer st=new StringTokenizer(time," :-.");
        int year=Integer.parseInt(st.nextToken());
        int month=Integer.parseInt(st.nextToken());
        int day=Integer.parseInt(st.nextToken());
        int hour=Integer.parseInt(st.nextToken());
        int minute=Integer.parseInt(st.nextToken());
        int sec=Integer.parseInt(st.nextToken());
        int nano=Integer.parseInt(st.nextToken());
        Timestamp t=new Timestamp(year, month, day, hour, minute, sec, nano);
        return t;
  }

     public static void recur_backtrack(String user,String topic,ArrayList<DataRecord> data_set,LoadingProb loadingProb,Timestamp ut)
     { 
         
          for(DataRecord d:data_set)
            {
             String time=d.timestamp; 
              Timestamp rt=getTimestamp(time);
              
             
           if(d.receiver.equals(user)&&d.fake.equalsIgnoreCase("fake")&&d.topic.equalsIgnoreCase(topic)&&ut.after(rt))
           {
               System.out.println(d.sender+" "+d.timestamp+"----->"+user+" ");
                recur_backtrack(d.sender, topic, data_set, loadingProb,rt);
               System.out.println(""+d.datarecord);
               if(bot_timTimestamp.after(rt))
               {
               bot_timTimestamp=rt;
               bot_user=d.receiver;
               }
           }
       
          }

     
     }
  }
