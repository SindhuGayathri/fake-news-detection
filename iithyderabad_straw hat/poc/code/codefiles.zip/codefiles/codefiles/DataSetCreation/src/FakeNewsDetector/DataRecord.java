
package FakeNewsDetector;

import java.util.StringTokenizer;

public class DataRecord 
{
  public String origin_of_news;
  public String fake;
  public String by_whom;
  public String by_field;
  public String about_whom;
  public String about_field;
  public String sender;
  public String receiver;
  public String topic;
  public String analysis;
  public String timestamp;
  public String datarecord;
  public DataRecord(String data_record)
  {
      this.datarecord=data_record;
    //    String data="Facebook,fake,ameerkhan,Movies,Jagan,politics,fperson89,tperson10,topic92,Positive, 2017-11-05 15:23:44.888";
  
    StringTokenizer st=new StringTokenizer(data_record,", ");
    origin_of_news=st.nextToken();
    fake=st.nextToken();
    by_whom=st.nextToken();
    by_field=st.nextToken();
    about_whom=st.nextToken();
    about_field=st.nextToken();
    sender=st.nextToken();
    receiver=st.nextToken();
    topic=st.nextToken();
    analysis=st.nextToken();
    timestamp=st.nextToken()+" "+st.nextToken();
   }
  public String toString()
  {
  return datarecord;
  }
    
  public static void main(String args[])
  {
  String st="TheHindu,true,katreena,Movies,KTR,politics ,person49,person70,topic10,Negative, 2017-11-06 06:35:39.214";
  DataRecord d=new DataRecord(st);
      System.out.println(""+d);
  
  
  }
   

}
