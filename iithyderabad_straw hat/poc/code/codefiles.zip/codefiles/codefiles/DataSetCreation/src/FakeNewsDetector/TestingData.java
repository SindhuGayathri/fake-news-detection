/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import static FakeNewsDetector.DatasetRead.getProbVectors;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import test.LoadingProb;

 public class TestingData 
 {
 public static void main(String args[]) throws FileNotFoundException
 {

       
     
     
 }
         public ProbVector getProb(DataRecord dataRecord,LoadingProb loadingProb)
    {
                    ProbVector p=new ProbVector();
                    p.prob_orgin=(int)loadingProb.origin_news.get(dataRecord.origin_of_news);
                    p.prob_bywhom=(int)loadingProb.news_made.get(dataRecord.by_whom);
                    p.prob_sender=(int)loadingProb.about_person.get(dataRecord.sender);
                    p.prob_catagory=(int)loadingProb.category_news.get(dataRecord.about_field);
                    if(dataRecord.fake.equalsIgnoreCase("true"))
                    {
                        p.isfake=0;
                    }
                    else
                    {
                        p.isfake=1;
                    }
                     return  p;
        
        
    }

 public int test(ProbVector true_mean,ProbVector fake_mean,ProbVector input)
 {
     float fake_distance=getDistance(input,fake_mean);
     float true_distance=getDistance(input,true_mean);
     System.out.println(fake_distance+"--"+true_distance);
 
     if(fake_distance<true_distance)
     {
         return 1; 
     }
     return 0;
 
 }
        public  float getDistance(ProbVector p1,ProbVector p2)
    {
        float distance=(float) Math.pow((p1.prob_orgin-p2.prob_orgin),2);
        distance+=(float) Math.pow((p1.prob_bywhom-p2.prob_bywhom),2);
        distance+=(float) Math.pow((p1.prob_catagory-p2.prob_catagory),2);
        distance+=(float) Math.pow((p1.prob_sender-p2.prob_sender),2);
        distance=(float)Math.sqrt(distance);
        return distance;
    }

 }
