/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import test.LoadingProb;

/**
 *
 * @author Lenovo
 */
public class KMeansAlgorthm
{
public static void main(String args[]) throws FileNotFoundException
{
        ArrayList<DataRecord> data_set=DatasetRead.getLoadedList("updated_data_set.txt");
        LoadingProb loadingProb=new LoadingProb();
        
            int i=0;
            int no_true=0;
            int no_fake=0;
            
            int true_orgprob=0; 
            int true_bywhomprob=0;   
            int true_sendprob=0;    
            int true_catgoryprob=0;
            
            int fake_orgprob=0; 
            int fake_bywhomprob=0;   
            int fake_sendprob=0;    
            int fake_catgoryprob=0;
                       

        for(DataRecord d:data_set)
        {
            
          if(d.fake.equalsIgnoreCase("true"))
          {  
             true_orgprob+=(int)loadingProb.origin_news.get(d.origin_of_news);
             true_bywhomprob+=(int)loadingProb.news_made.get(d.by_whom);   
             true_sendprob+=(int)loadingProb.about_person.get(d.sender);   
             true_catgoryprob+=(int)loadingProb.category_news.get(d.about_field);
             no_true++;
          }
          else
          {
             fake_orgprob+=(int)loadingProb.origin_news.get(d.origin_of_news);
             fake_bywhomprob+=(int)loadingProb.news_made.get(d.by_whom);   
             fake_sendprob+=(int)loadingProb.about_person.get(d.sender);   
             fake_catgoryprob+=(int)loadingProb.category_news.get(d.about_field);
             no_fake++;
           }
        }
        System.out.println(""+no_true);
        System.out.println(""+no_fake);
        
        System.out.print("("+(true_orgprob)/no_true);
        System.out.print(" ,"+(true_bywhomprob)/no_true);
        System.out.print(" ,"+(true_sendprob)/no_true);
        System.out.println(", "+(true_catgoryprob/no_true)+")");
        
        System.out.print("("+(fake_orgprob/no_fake));
        System.out.print(","+(fake_bywhomprob/no_fake));
        System.out.print(","+(fake_sendprob/no_fake));
        System.out.print(","+(fake_catgoryprob/no_fake)+")");
        
        JOptionPane.showMessageDialog(null,"Its completed");

}
}
