/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import test.LoadingProb;

 public class DatasetRead {
    public static void main(String[] args) throws FileNotFoundException, IOException 
    {
       ArrayList<DataRecord> data_set=DatasetRead.getLoadedList("updated_data_set.txt");
       LoadingProb loadingProb=new LoadingProb();
       ArrayList<ProbVector> probVectors=getProbVectors(data_set, loadingProb);
       
       
//System.out.println(""+p.prob_orgin);
       
       
       
       /* for(ProbVector p:probVectors)
         {
             System.out.println(""+p.isfake);
         }
      */
       
//        JOptionPane.showMessageDialog(null,probVectors.size());
    }
       
    public static ArrayList<ProbVector> getProbVectors(ArrayList<DataRecord> data_set,LoadingProb loadingProb)
    {
        ArrayList<ProbVector> probVectors=new ArrayList<ProbVector>();
        int i=0;
        for(DataRecord d:data_set)
        {
         // System.out.print(i+"");
          ProbVector p=getProb(d, loadingProb);
          probVectors.add(p);
          i++;
         }
        System.out.println(""+probVectors.size());
        return  probVectors;
     }
        public static ProbVector getProb(DataRecord dataRecord,LoadingProb loadingProb)
    {
                    ProbVector p=new ProbVector();
                    p.prob_orgin=(int)loadingProb.origin_news.get(dataRecord.origin_of_news);
                    p.prob_bywhom=(int)loadingProb.news_made.get(dataRecord.by_whom);
                    p.prob_sender=(int)loadingProb.about_person.get(dataRecord.sender);
                    p.prob_catagory=(int)loadingProb.category_news.get(dataRecord.about_field);
                    if(dataRecord.fake.equalsIgnoreCase("true"))
                    {
                        p.isfake=0;
                    }
                    else
                    {
                        p.isfake=1;
                    }
                     return  p;
        
        
    }
  
    
    
    
    
    public static ArrayList<DataRecord> getLoadedList(String fileName) throws FileNotFoundException
    {
        ArrayList<DataRecord> loadedList=new ArrayList<DataRecord>();
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            int i=0;
            while ((line = br.readLine()) != null) 
            {
        //    System.out.println(i+""+line);
            DataRecord d=new DataRecord(line);
            loadedList.add(d);
            i++;
             }
         }
        catch(Exception e)
        {
        }
          return loadedList;
    }
    
  public static int getRandom(int length)
  {
    int n=(int)(Math.floor(Math.random()*length));
    return n;
  }
  public static String getRandomString(ArrayList<String> a)
  {
        String s1=a.get(OldDatasetCreation.getRandom(a.size()));
        return s1;
  }
    
    
   public static void printTime()
   {
         Timestamp timestamp = new Timestamp(System.currentTimeMillis());
         System.out.print(" "+timestamp);

   }

 }


