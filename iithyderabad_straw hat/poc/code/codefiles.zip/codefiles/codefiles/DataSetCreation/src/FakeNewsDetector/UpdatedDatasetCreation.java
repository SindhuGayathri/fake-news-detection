/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package FakeNewsDetector;

import static FakeNewsDetector.OldDatasetCreation.getRandom;
import static FakeNewsDetector.OldDatasetCreation.getRandomString;
import static FakeNewsDetector.OldDatasetCreation.printTime;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.StringTokenizer;

 public class UpdatedDatasetCreation {
    public static void main(String[] args) throws FileNotFoundException, IOException 
    {
        ArrayList<Data> news=getLoadedList("origin_of_news.txt");
         int fake_count[]=new int[news.size()] ;
         ArrayList<String> news_made=OldDatasetCreation.getLoadedList("news_made_without_prob.txt");
        ArrayList<String> origin_of_news=OldDatasetCreation.getLoadedList("origin_of_news_without_prob.txt");
        ArrayList<String> category=OldDatasetCreation.getLoadedList("category.txt");

        while(true)
        {
        
            int from_fakeperson=getRandom(100);
            int origin_index=UpdatedDatasetCreation.getRandom(origin_of_news.size());
            System.out.print(""+getRandomString(origin_of_news,origin_index));
            fake_count[origin_index]=(fake_count[origin_index]+1)%100;
            if(from_fakeperson==9||from_fakeperson==18||from_fakeperson==6)
            {
               System.out.print(",fake");
            }
            else
            {
            if(fake_count[origin_index]<news.get(origin_index).prob)
            {
                System.out.print(",fake");
            }
            else
            {
                System.out.print(",true");
            }
            }
        System.out.print(","+getRandomString(news_made));
        System.out.print(","+getRandomString(news_made));
        System.out.print(",person"+from_fakeperson+","+"person"+getRandom(100));
        System.out.print(",topic"+getRandom(100));
        int dec=getRandom(2);
        if(dec==0)
        {
            System.out.print(",Negative,");
        }
        else
        {
            System.out.print(",Positive,");
         }
         printTime();
        System.out.println("");
        }
        
        
        
        
        
        
   }
  public static int getRandom(int length)
  {
  int n=(int)(Math.floor(Math.random()*length));
  return n;
  }
  public static String getRandomString(ArrayList<String> a)
  {
        String s1=a.get(UpdatedDatasetCreation.getRandom(a.size()));
        return s1;
  }
  public static String getRandomString(ArrayList<String> a,int index)
  {
        String s1=a.get(index);
        return s1;
  }
    
    
   public static void printTime()
   {
         Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        System.out.print(" "+timestamp);

   }
    
    
    
    
    public static ArrayList<Data> getLoadedList(String fileName) throws FileNotFoundException
    {
        ArrayList<Data> loadedList=new ArrayList<Data>();
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = br.readLine()) != null) 
            {
    //        System.out.println(""+line);
            loadedList.add(new Data(line));
            }
         }
        catch(Exception e)
        {
        }
    
         return loadedList;
    }
 }
class Data
{
public String  field;
public int prob;
public Data(String data)
{
StringTokenizer st=new StringTokenizer(data,":");
field=st.nextToken();
prob=Integer.parseInt(st.nextToken());
   // System.out.println(field+""+prob);    
}

}

